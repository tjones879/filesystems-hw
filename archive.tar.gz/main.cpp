#define FUSE_USE_VERSION 31
#include <fuse3/fuse.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <stddef.h>
#include <assert.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#ifdef HAVE_SETXATTR
#include <sys/xattr.h>
#endif

#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <boost/iostreams/filtering_streambuf.hpp>
#include <boost/iostreams/copy.hpp>
#include <boost/iostreams/filter/gzip.hpp>

namespace bio {
    using namespace boost::iostreams;
}


struct Archive {
    std::string filename;
    std::vector<unsigned char> contents;
};

Archive archive;

void decompress()
{
}

void *compress_init(struct fuse_conn_info *conn,
                    struct fuse_config *cfg)
{
    cfg->kernel_cache = 1;
    cfg->nullpath_ok = 1;
    cfg->entry_timeout = 0;
    cfg->attr_timeout = 0;
    cfg->negative_timeout = 0;

    return NULL;
}

int compress_getattr(const char *path, struct stat *stbuf,
                  struct fuse_file_info *fi)
{
    int res = 0;

    if (fi)
        res = fstat(fi->fh, stbuf);
    else
        res = lstat(path, stbuf);

    if (res == -1)
        return -errno;

    return 0;
}

struct Dirp {
    DIR *ptr;
    struct dirent *entry;
    off_t offset;
};

Dirp *getDirp(struct fuse_file_info *fi)
{
    return (Dirp *) (uintptr_t) fi->fh;
}

static int compress_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
                  off_t offset, struct fuse_file_info *fi,
                  enum fuse_readdir_flags flags)
{
    //decompress();
    auto *d = getDirp(fi);

    if (offset != d->offset) {
        seekdir(d->ptr, offset - 1);
        d->entry = NULL;
        d->offset = offset;
    }
    while (true) {
        struct stat st;
        off_t nextOffset;
        auto fill_flags = 0;

        if (!d->entry) {
            d->entry = readdir(d->ptr);
            if (!d->entry)
                break;
        }
        if (flags & FUSE_READDIR_PLUS) {
            int res = fstatat(dirfd(d->ptr), d->entry->d_name, &st,
                              AT_SYMLINK_NOFOLLOW);
            if (res != -1)
                fill_flags |= (FUSE_FILL_DIR_PLUS);
        }
        if (!(fill_flags & FUSE_FILL_DIR_PLUS)) {
            memset(&st, 0, sizeof(st));
            st.st_ino = d->entry->d_ino;
            st.st_mode = d->entry->d_type << 12;
        }
        nextOffset = telldir(d->ptr);
        if (filler(buf, d->entry->d_name, &st, nextOffset,
                   static_cast<enum fuse_fill_dir_flags>(fill_flags)))
            break;

        d->entry = NULL;
        d->offset = nextOffset;
    }

    return 0;
}

static int compress_opendir(const char *path, struct fuse_file_info *fi)
{
    int res;
    if (!strcmp(path, "/")) {
        std::cout << "Opening root" << std::endl;
    } else {
        std::cout << "Opening " << std::string(path) << std::endl;
    }
    // Extract .gz
    // list manifest of .tar
    /*
    struct Dirp *d = new Dirp();

    d->ptr = opendir(path);
    if (!d->ptr) {
        res = -errno;
        delete d;
        return res;
    }
    d->offset = 0;
    d->entry = NULL;
    fi->fh = (unsigned long) d;
    */
    return 0;
}

bool matchExtension(const std::string path, const std::string extension)
{
    auto chars = extension.length();
    auto ending = path.substr(path.size() - chars, chars);
    return extension == ending;
}

static int compress_open(const char *path, struct fuse_file_info *fi)
{
    auto mod = 'r';
    int fd = 0;

    if (fi->flags & O_WRONLY || fi->flags & O_APPEND)
        return -ENOENT;

    std::cout << std::string(path) << std::endl;
    fd = open(path, fi->flags);

    if (fd == -1)
        return -errno;

    fi->fh = fd;

    return 0;
}

int compress_read(const char *path, char *buf, size_t size, off_t offset,
               struct fuse_file_info *fi)
{
    int ret;

    ret = pread(fi->fh, buf, size, offset);
    if (ret == -1)
        ret = -errno;

    return ret;
}

struct fuse_operations compress_oper;

void readTar(const std::string &str)
{
    std::cout << "HEADER:" << std::endl;
    std::cout << str.substr(0, 512) << std::endl;
}

int main(int argc, char *argv[])
{
    compress_oper.init    = compress_init;
    compress_oper.getattr = compress_getattr;
    compress_oper.readdir = compress_readdir;
    compress_oper.open    = compress_open;
    //compress_oper.opendir = compress_opendir;
    compress_oper.read    = compress_read;

    archive.filename = argv[1];
    std::cout << archive.filename << std::endl;
    std::fstream compressed(archive.filename);
    std::stringstream decompressed;

    bio::filtering_streambuf<bio::input> out;
    out.push(bio::gzip_decompressor());
    out.push(compressed);
    bio::copy(out, decompressed);

    readTar(decompressed.str());


    return fuse_main(argc - 1, argv + 1, &compress_oper, NULL);
}
